package com.example.makeyourapp_mya.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.makeyourapp_mya.MainActivity;
import com.example.makeyourapp_mya.R;

public class ActivityCadastro extends AppCompatActivity {

    Dialog myDialog;

    private EditText edNome, edEmail, edSenha, edCpf, edRptSenha;
    private Button btCadastrar;
    private TextView textVoltar;
    DBHelper dbHelper;

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edNome = (EditText) findViewById(R.id.edtNome);
        edEmail = (EditText) findViewById(R.id.edtEmail);
        edCpf = (EditText) findViewById(R.id.edtCpf);
        edSenha = (EditText) findViewById(R.id.edtSenha);
        edRptSenha = (EditText) findViewById(R.id.edtRepetirSenha);
        textVoltar = (TextView) findViewById(R.id.txtVoltar);
        btCadastrar = (Button) findViewById(R.id.btnCadastrar);
        dbHelper = new DBHelper(this);

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome1, email1, cpf1, senha1, rptSenha1;
                nome1 = edNome.getText().toString();
                email1 = edEmail.getText().toString();
                cpf1 = edCpf.getText().toString();
                senha1 = edSenha.getText().toString();
                rptSenha1 = edRptSenha.getText().toString();

                if (nome1.equals("") || email1.equals("") || cpf1.equals("") || senha1.equals("") || rptSenha1.equals("")) {
                    Toast.makeText(ActivityCadastro.this, "Por favor preencha todos os campos necessários!", Toast.LENGTH_SHORT).show();
                } else {
                    if (senha1.equals(rptSenha1)){
                        if (dbHelper.confirmarUsuario(email1)){
                            Toast.makeText(ActivityCadastro.this, "Esse usuário já existe", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        boolean registroFeito = dbHelper.inserirDados(nome1, email1, cpf1, senha1);
                        if (registroFeito) {
                            Toast.makeText(ActivityCadastro.this, "Usuario registrado com sucesso!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ActivityCadastro.this, MainActivity.class);
                            startActivity(intent);
                        }else {
                            Toast.makeText(ActivityCadastro.this, "Não foi possível registrar o usuario", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(ActivityCadastro.this, "As senhas não coincidem", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        textVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ActivityCadastro.this, MainActivity.class);
                startActivity(i);
            }
        });

    }


}
