package com.example.makeyourapp_mya.Activity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBName = "mya.bd";

    public DBHelper(@Nullable Context context) {
        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS usuarios(id INT primary key, nome VARCHAR(100), email VARCHAR(100) UNIQUE, cpf INT(11) UNIQUE, senha VARCHAR(50))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists usuarios");
    }

    public boolean inserirDados(String nome, String email, String cpf, String senha) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("nome", nome);
        contentValues.put("email", email);
        contentValues.put("cpf", cpf);
        contentValues.put("senha", senha);
        long result = myDB.insert("usuarios", null, contentValues);
        if (result == -1) return false;
        else return true;
    }

    public boolean confirmarUsuario(String email) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("select * from usuarios where nome = ?", new String[]{email});
        if (cursor.getCount() > 0)
            return true;
        else return false;
    }

    public boolean confirmarUsuario(String email, String senha1){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("select * from usuarios where nome = ? and senha = ?", new String[]{email, senha1});
        if (cursor.getCount() > 0)
            return true;
        else return false;
    }
}
